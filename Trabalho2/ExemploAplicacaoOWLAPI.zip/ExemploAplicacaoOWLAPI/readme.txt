INE6019000 - Intelig�ncia Artificial Simb�lica
Prof. Ricardo Azambuja Silveira
Julho 2014


Trabalho Pr�tico Final


Alunos: Jo�o de Amorim Junior - 201400411
	Thiago Angelo Gelaim  - 201400410


Arquivos: TrabalhoFinalIA_JoaoAmorimThiagoGelaim.pdf - Slides da apresenta��o

          src.zip - Fontes da aplica��o (Java)

          concecionaria.owl - Ontologia utilizada na aplica��o (URI: http://liate.inf.ufsc.br/~thiago/concessionaria.owl)

          concessionariaDeAutomoveisVrsFinal.jar - Execut�vel da aplica��o